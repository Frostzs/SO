#include "api.h"

#include <assert.h>
#include <errno.h>
#include <fcntl.h>
#include <limits.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <stdint.h>

#define PATH_SIZE (40)
char req_pipe[PATH_SIZE];
char resp_pipe[PATH_SIZE];
int server, reqPipe, respPipe;

int ems_setup(char const* req_pipe_path, char const* resp_pipe_path, char const* server_pipe_path) {
  // TODO: create pipes and connect to the server
  //  Remove pipe if it does not exist

  memset(req_pipe, '\0', PATH_SIZE - 1);
  memset(resp_pipe, '\0', PATH_SIZE - 1);
  strncpy(req_pipe, req_pipe_path, strlen(req_pipe_path));
  strncpy(resp_pipe, resp_pipe_path, strlen(resp_pipe_path));

  // Create request pipe
  if (mkfifo(req_pipe_path, 0640) != 0 && errno != EEXIST) {
    fprintf(stderr, "[ERR]: mkfifo failed: %s\n", strerror(errno));
    exit(EXIT_FAILURE);
  }

  // Create response pipe
  if (mkfifo(resp_pipe_path, 0640) != 0 && errno != EEXIST) {
    fprintf(stderr, "[ERR]: mkfifo failed: %s\n", strerror(errno));
    exit(EXIT_FAILURE);
  }
  
  // Open server pipe to write
  server = open(server_pipe_path, O_WRONLY);
  if (server == -1) {
    fprintf(stderr, "[ERR]: open failed: %s\n", strerror(errno));
    exit(EXIT_FAILURE);
  }



  char opcode = '1';
  write(server, &opcode, sizeof(uint8_t));
  write(server, req_pipe, PATH_SIZE);
  write(server, resp_pipe, PATH_SIZE);

  reqPipe = open(req_pipe_path, O_WRONLY);
  if (reqPipe == -1) {
    fprintf(stderr, "[ERR]: open failed: %s\n", strerror(errno));
    exit(EXIT_FAILURE);
  }
  
  respPipe = open(resp_pipe_path, O_RDONLY);
  if (respPipe == -1) {
    fprintf(stderr, "[ERR]: open failed: %s\n", strerror(errno));
    exit(EXIT_FAILURE);
  }

  return 0;
}

int ems_quit(void) {
  char opcode = '2';

  write(reqPipe, &opcode, sizeof(uint8_t));
  close(reqPipe);
  close(respPipe);
  if (unlink(resp_pipe) != 0 && errno != ENOENT) {
    fprintf(stderr, "[ERR]: unlink(%s) failed: %s\n", resp_pipe, strerror(errno));
    exit(EXIT_FAILURE);
  }

  if (unlink(req_pipe) != 0 && errno != ENOENT) {
    fprintf(stderr, "[ERR]: unlink(%s) failed: %s\n", req_pipe, strerror(errno));
    exit(EXIT_FAILURE);
  }

  close(server);
  return 0;
}

int ems_create(unsigned int event_id, size_t num_rows, size_t num_cols) {
  // TODO: send create request to the server (through the request pipe) and wait for the response (through the response
  // pipe) 
  //Falta receber resposta 

  // Open pipe for writing
  // This waits for someone to open it for reading

  char opcode = '3';


  write(reqPipe, &opcode, sizeof(uint8_t));
  write(reqPipe, &event_id, sizeof(unsigned int));
  write(reqPipe, &num_rows, sizeof(size_t));
  write(reqPipe, &num_cols, sizeof(size_t));
  // int result;
  // read(respPipe, &result, sizeof(int));    fica preso no read
  // if (result == 1){
  //  printf("ERROR: Couldn't create event\n");
  //  }
  return 0;
}

int ems_reserve(unsigned int event_id, size_t num_seats, size_t* xs, size_t* ys) {
  // TODO: send reserve request to the server (through the request pipe) and wait for the response (through the response
  // pipe)

  // Open pipe for writing
  // This waits for someone to open it for reading

  char opcode = '4';

  write(reqPipe, &opcode, sizeof(uint8_t));
  write(reqPipe, &event_id, sizeof(unsigned int));
  write(reqPipe, &num_seats, sizeof(size_t));
  write(reqPipe, xs, sizeof(size_t[num_seats]));
  write(reqPipe, ys, sizeof(size_t[num_seats]));
  
  // int result;
  // read(respPipe, &result, sizeof(int));    fica preso no read
  // if (result == 1){
  //  printf("ERROR: Couldn't reserve event\n");
  //  }

  return 0;
}

int ems_show(int out_fd, unsigned int event_id) {
  // TODO: send show request to the server (through the request pipe) and wait for the response (through the response
  // pipe)

  // Open pipe for writing
  // This waits for someone to open it for reading
  char opcode = '5';

  write(reqPipe, &opcode, sizeof(uint8_t));
  write(reqPipe, &event_id, sizeof(unsigned int));

  /* while (true) {
        char buffer[256];
        ssize_t ret = read(respPipe, buffer, 255);      fica preso no read
        if (ret == 0) {
            // ret == 0 indicates EOF
            break;
        } else if (ret == -1) {
            // ret == -1 indicates error
            fprintf(stderr, "[ERR]: read failed: %s\n", strerror(errno));
            exit(EXIT_FAILURE);
        }

        buffer[ret] = 0;
        write(out_fd, &buffer, 255);
    }*/

  char *test = "test";
  write(out_fd, test, strlen(test));  // apenas para tirar o warning da consola
  
  return 0;
}

int ems_list_events(int out_fd) {
  // TODO: send list request to the server (through the request pipe) and wait for the response (through the response
  // pipe)

  char opcode = '6';

  write(reqPipe, &opcode, sizeof(uint8_t));

  char *test = "test";
  write(out_fd, test, strlen(test));  // apenas para tirar o warning da consola
  return 0;
}