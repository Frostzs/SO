/*
Realizado por: Eduardo Barata nº106531, Rafael Vilas Boas nº103703 - grupo Tg086
*/


#include <limits.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <unistd.h>
#include <stdint.h>


#include "common/constants.h"
#include "common/io.h"
#include "operations.h"

#define BUFFER_SIZE (256)
#define FIFO_SIZE (40)

typedef struct Client
{
  int session_id;
  char *request_pipe;
  char *response_pipe;
} Client;

enum Choice {
  CMD_QUIT = 50, // numero 2 na tabela ASCII
  CMD_CREATE,
  CMD_RESERVE,
  CMD_SHOW,
  CMD_LIST_EVENTS
};



int main(int argc, char* argv[]) {
  if (argc < 2 || argc > 3) {
    fprintf(stderr, "Usage: %s\n <pipe_path> [delay]\n", argv[0]);
    return 1;
  }
  char* endptr;
  unsigned int state_access_delay_us = STATE_ACCESS_DELAY_US;
  if (argc == 3) {
    unsigned long int delay = strtoul(argv[2], &endptr, 10);

    if (*endptr != '\0' || delay > UINT_MAX) {
      fprintf(stderr, "Invalid delay value or value too large\n");
      return 1;
    }

    state_access_delay_us = (unsigned int)delay;
  }

  if (ems_init(state_access_delay_us)) {
    fprintf(stderr, "Failed to initialize EMS\n");
    return 1;
  }
  
  char server_path[FIFO_SIZE];
  memset(server_path, '\0', FIFO_SIZE * sizeof(char));
  strncpy(server_path, argv[1], strlen(argv[1]) * sizeof(char));
  // strcat(server_path, ".pipe");

  //TODO: Intialize server, create worker threads
  
  // Create server pipe
  if (mkfifo(server_path, 0640) != 0 && errno != EEXIST) {
    fprintf(stderr, "[ERR]: mkfifo failed: %s\n", strerror(errno));
    exit(EXIT_FAILURE);
  }
  
  // open the server pipe to read
  int server = open(server_path, O_RDONLY);
  if (server == -1) {
    fprintf(stderr, "[ERR]: open failed: %s\n", strerror(errno));
    exit(EXIT_FAILURE);
  }

  Client *client;
  client = malloc(sizeof(Client));
  int OP_CODE;

  unsigned int event_id;
  size_t num_rows;
  size_t num_cols;
  size_t num_seats;
  size_t xs[100];
  size_t ys[100];
  char req_pipe[FIFO_SIZE];
  char resp_pipe[FIFO_SIZE];
  int req_fd, resp_fd = 0;
  //int result;

  while (1) {
    //TODO: Read from pipe
    ssize_t ret = read(server, &OP_CODE, sizeof(uint8_t));
    
    if (ret == -1) {
      fprintf(stderr, "[ERR]: read failed: %s\n", strerror(errno));
      exit(EXIT_FAILURE);
    }

    if (ret > 0 && OP_CODE == '1')
    {
      read(server, req_pipe, FIFO_SIZE);
      read(server, resp_pipe, FIFO_SIZE);
      client->response_pipe = resp_pipe;
      client->request_pipe = req_pipe;
      req_fd = open(req_pipe, O_RDONLY);
      resp_fd = open(resp_pipe, O_WRONLY);
      continue;
    }
    
    ssize_t ret2 = read(req_fd, &OP_CODE, sizeof(uint8_t));
    if (ret2 == 0) {
      continue;
    }

    if (ret2 == -1) {
      fprintf(stderr, "[ERR]: read failed: %s\n", strerror(errno));
      exit(EXIT_FAILURE);
    }


    switch (OP_CODE)
    {
    case CMD_QUIT: // funcao termina o servidor pois nao foi possivel fazer com varios clientes
      client->session_id = 0;
      free(client);
      goto exit_while;

    case CMD_CREATE:
      read(req_fd, &event_id, sizeof(unsigned int));
      read(req_fd, &num_rows, sizeof(size_t));
      read(req_fd, &num_cols, sizeof(size_t));
      /*result =*/ems_create(event_id, num_rows, num_cols);
      // write(resp_fd, &result, sizeof(int));

      // write deixa o programa em loop, não saindo do case

      break;

    case CMD_RESERVE:
      read(req_fd, &event_id, sizeof(unsigned int));
      read(req_fd, &num_seats, sizeof(size_t));
      read(req_fd, xs, sizeof(size_t[num_seats]));
      read(req_fd, ys, sizeof(size_t[num_seats]));

      /*result =*/ems_reserve(event_id, num_seats, xs, ys);
      // write(resp_fd, &result, sizeof(int));

      // write deixa o programa em loop, não saindo do case
      break;

    case CMD_SHOW:
      read(req_fd, &event_id, sizeof(unsigned int));
      /*result =*/ems_show(resp_fd, event_id);
      break;

    case CMD_LIST_EVENTS:
      /*result =*/ ems_list_events(resp_fd);
      break;

    default:
      break;
    }
    //TODO: Write new client to the producer-consumer buffer
  }

  //TODO: Close Server
  exit_while: ;

  if (unlink(server_path) != 0 && errno != ENOENT) {
    fprintf(stderr, "[ERR]: unlink(%s) failed: %s\n", server_path, strerror(errno));
    exit(EXIT_FAILURE);
  }

  close(server);
  close(resp_fd);
  close(req_fd);
  ems_terminate();
}